#include "stdafx.h"
#include "DataLoader.h"

namespace Data {

std::unique_ptr<DataModel> LoadFromDat(const std::wstring & path)
{
	return std::unique_ptr<DataModel>();
}

} // namespace Data 
